package pack.com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Forget
 */
@WebServlet("/Forget")
public class Forget extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Forget() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		String username = request.getParameter("uname");
		String password = request.getParameter("pass");
		String repassword = request.getParameter("repass");
		
		if(password.equals(repassword))
		{
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection cn = DriverManager.getConnection("jdbc:mysql://128.66.203.247/imsc7it193","imsc7it193","sumo@123");
			
				PreparedStatement ps = cn.prepareStatement("UPDATE signup SET password = ? WHERE username = ?");
				
				ps.setString(1,password);
				ps.setString(2,username);
				
				int rs = ps.executeUpdate();
				if(rs>0) {
					response.sendRedirect("work.jsp");
				}
				else {
					response.sendRedirect("error.jsp");
				}
				
			}
			catch (Exception e){
				System.out.print(e);
			}
		}
		
	}
}

